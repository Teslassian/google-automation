Windows Application Driver (Beta)

For documentation, sample code, and logging issues: 
https://github.com/Microsoft/WinAppDriver

To request new features and upvote requests filed by others: 
https://wpdev.uservoice.com
