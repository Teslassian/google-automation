# Windows Terminal and Console Assets

## Images

The images in this directory do not fall under the same [license](https://raw.githubusercontent.com/microsoft/terminal/master/LICENSE) as the rest
of the Windows Terminal code.

Please consult the [license](./LICENSE) in this directory for terms applicable to the image assets in this directory.

## Fonts

The fonts in this directory do not fall under the same [license](https://raw.githubusercontent.com/microsoft/terminal/master/LICENSE) as the rest
of the Windows Terminal code.

Please consult the [license](https://raw.githubusercontent.com/microsoft/cascadia-code/master/LICENSE) in the
[microsoft/cascadia-code](https://github.com/microsoft/cascadia-code) repository for terms applicable to the fonts in this directory.

### Fonts Included

* Cascadia Code
   * from microsoft/cascadia-code@d733599504811e8f3969de20368817d20e162dba
