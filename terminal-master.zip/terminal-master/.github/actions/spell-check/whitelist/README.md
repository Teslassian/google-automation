The contents of each `.txt` file in this directory are merged together.

* [alphabet](alphabet.txt) is a sample for alphabet related items
* [web](web.txt) is a sample for web/html related items
* [whitelist](whitelist.txt) is the main whitelist -- there is nothing
particularly special about the file name (beyond the extension which is
important).
